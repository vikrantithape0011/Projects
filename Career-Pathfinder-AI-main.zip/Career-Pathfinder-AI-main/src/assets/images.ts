// Placeholder exports for images
export const patternTriangles = '/assets/images/pattern-triangles.png';
export const cubeNet = '/assets/images/cube-net.png';
export const numberPattern = '/assets/images/number-pattern.png';
export const cubePatterns = '/assets/images/cube-patterns.png';
export const facialExpression = '/assets/images/facial-expression.png'; 